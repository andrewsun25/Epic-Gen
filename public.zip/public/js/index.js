if (!Detector.webgl) Detector.addGetWebGLMessage();
// Globals
var gCamera, gControls, gScene, gRenderer;

// Objects
var gHelper, gObjects = [];

// Raycasting
var gRaycaster = new THREE.Raycaster();
var gMouse = new THREE.Vector2();

const CUBE_SIZE = 10;

// Kick it off
init();
//render(); // remove when using next line for animation loop (requestAnimationFrame)
animate();

function init() {

    // Scene, Renderer, Camera, Controls

    gScene = new THREE.Scene();
    gScene.background = new THREE.Color(0xcccccc);
    gScene.fog = new THREE.FogExp2(0xcccccc, 0.002);

    var gridHelper = new THREE.GridHelper(100, 100, 0x0000ff, 0x808080);
    gScene.add(gridHelper);

    gRenderer = new THREE.WebGLRenderer({
        antialias: true
    });
    gRenderer.setPixelRatio(window.devicePixelRatio);
    gRenderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(gRenderer.domElement);

    gCamera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 1, 1000);
    gCamera.position.set(0, 20, 20); // y==200, z==200
    // gControls
    gControls = new THREE.OrbitControls(gCamera, gRenderer.domElement); // we are controlling the global gCamera and listening for orbit events from the canvas 
    gControls.enableDamping = true; // an animation loop is required when either damping or auto-rotation are enabled
    gControls.dampingFactor = 0.15;
    gControls.screenSpacePanning = false;
    gControls.minDistance = 1; // closest we can dolly in to origin. 
    gControls.maxDistance = 20; // furtherest out we can get
    gControls.maxPolarAngle = Math.PI / 2; // angle by which we can deviate from y axis(in radians). Defines a cone.


    // Cubes

    var geometry = new THREE.BoxBufferGeometry(CUBE_SIZE, CUBE_SIZE, CUBE_SIZE);
    
    for (var i = 0; i < 10; i++) {
        var object = new THREE.Mesh(geometry, new THREE.MeshLambertMaterial({ color: Math.random() * 0xffffff }));
        object.position.x = Math.random() * 200 - 100;
        object.position.z = Math.random() * 200 - 100;
        object.rotation.x = Math.random() * 2 * Math.PI;
        object.rotation.z = Math.random() * 2 * Math.PI;
        object.scale.x = Math.random() * 2 - 1;
        object.scale.y = Math.random() * 2 - 1;
        object.scale.z = Math.random() * 2 - 1;
        object.castShadow = true;
        object.receiveShadow = true;
        gScene.add(object);
        gObjects.push(object);
    }

    // Lights

    var light = new THREE.DirectionalLight(0xffffff);
    light.position.set(1, 1, 1); // position is a Vector3 with default value (0, 1, 0)
    gScene.add(light);
    var light = new THREE.DirectionalLight(0x002288);
    light.position.set(-1, -1, -1);
    gScene.add(light);
    var light = new THREE.AmbientLight(0x222222);
    gScene.add(light);

    // Event listeners

    window.addEventListener('resize', onWindowResize, false); // false means event won't be executed in capturing phase
    // window.addEventListener('mousemove', onMouseMove, false);
}


// Graphics

function animate() {
    requestAnimationFrame(animate); // Asynchronously calls animate function when the next repaint can happen IE when call stack is clear. 
    gControls.update(); // only required if gControls.enableDamping = true, or if gControls.autoRotate = true
    render();
}

function render() {
    gRenderer.render(gScene, gCamera); // renders to the canvas
}


// Doc event listeners

// function onMouseMove(event) {
//     gMouse.x = (event.clientX / window.innerWidth) * 2 - 1;
//     gMouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
//     // update the picking ray with the gCamera and gMouse position
//     gRaycaster.setFromCamera(gMouse, gCamera);
//     if (gBoard != undefined) {
//         var intersects = gRaycaster.intersectObject(gBoard, true);
//         // Toggle rotation bool for meshes that we clicked
//         if (intersects.length > 0) {
//             gHelper.position.set(0, 0, 0);
//             gHelper.lookAt(intersects[0].face.normal);
//             gHelper.position.copy(intersects[0].point);
//         }
//     }
// }

function onWindowResize() {
    gCamera.aspect = window.innerWidth / window.innerHeight; // update aspect ratio for perspective gCamera
    gCamera.updateProjectionMatrix(); // update the gCamera's internal proj matrix
    gRenderer.setSize(window.innerWidth, window.innerHeight); // resize gRenderer
}