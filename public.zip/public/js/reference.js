import * as THREE from 'https://cdnjs.cloudflare.com/ajax/libs/three.js/94/three.js';
// var THREE = require('three');
// var OBJLoader = require('three-obj-loader');
// OBJLoader(THREE);
/*
	Objects + Lights + Cameras == a Scene.
	Add stuff to scene using Scene.add(object).
*/
var scene = new THREE.Scene();
var axesHelper = new THREE.AxesHelper(5);
scene.add(axesHelper);
/*
	@fov: Field of view 
	@aspect ratio: Frustum aspect ratio
	@near: Distance from camera to near plane (always positive)
	@far: Distance from camera to far plane (always positive)
	Inherits from Camera class. 
	Also inherits from Object3D class which most threejs objects do. 
*/
var camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
/*
	WebGLRenderer() constructor takes optional params object with properties that specify options for renderer.
*/
var renderer = new THREE.WebGLRenderer();

/*
	@canvas and viewport width
	@canvas and viewport height
	@whether to update sizes
*/
renderer.setSize(window.innerWidth, window.innerHeight, true);
document.body.appendChild(renderer.domElement);

/*
	@x width, @y height, @z depth.
	Inherits from Geometry class which stores attributes such as 
	vertex positions, faces, colors.
*/
var geometry = new THREE.BoxGeometry(2, 1, 1);

// Texturing
texture = new THREE.TextureLoader().load("../res/textures/cat.png");

/*
	Inherits from Material. Flat material uneffected by lights. 
*/
var material = new THREE.MeshBasicMaterial({
	map: texture,
	color: 0x00ff00
});
var material2 = new THREE.MeshBasicMaterial({
	color: 0x4286f4
});
/*
	Geometry object + Material object == Mesh.
*/
var cube = new THREE.Mesh(geometry, material);


var cube2 = new THREE.Mesh(geometry, material2);
var group = new THREE.Group();
var m = new THREE.Matrix4();
m.makeTranslation(1, 0, -1);
cube2.applyMatrix(m);
group.add(cube);
group.add(cube2);
// a group inherits from Object3D and just makes thigns easier to work with.
group.applyMatrix(m);
scene.add(group);

// threejs uses RH coordinate system
camera.position.z = 5;

var animate = function() {
	requestAnimationFrame(animate);

	cube.rotation.x += 0.01;
	cube.rotation.y += 0.01;

	cube2.rotation.x += 0.01;
	cube2.rotation.y += 0.01;

	board.rotation.x += 0.01;
	board.rotation.y += 0.01;

	renderer.render(scene, camera);
};



var spinner_obj = new THREE.Object3D();
THREE.EventDispatcher.call(spinner_obj);
spinner_obj.addEventListener('start', function(event) {
	console.log("GOT THE EVENT");
});
spinner_obj.dispatchEvent({
	type: 'start'
});

// How to write a custom shader
/*
const material = new THREE.RawShaderMaterial({
  vertexShader: fs.readFileSync(path.join(__dirname, 'shader.vert'), 'utf8'),
  fragmentShader: fs.readFileSync(path.join(__dirname, 'shader.frag'), 'utf8'),
  uniforms: {
    u_time: { type: 'f', value: 0 }
  } // alerts threeJS of the presence of a "uniform float u_time" in the shader with a default value of 0.
  
});
*/

// look up how to do animations

var pointLight = new THREE.PointLight( 0xff0000, 1, 100 );
pointLight.position.set( 10, 10, 10 );
scene.add( pointLight );


var objLoader = new THREE.OBJLoader();
objLoader.setPath('../res/models/');
var board;
objLoader.load('board.obj', function(object) {
	object.material = material;
	object.scale = object.scale.multiplyScalar(10);
	scene.add(object);
	board = object;
	object.updateMatrixWorld();
});

animate();